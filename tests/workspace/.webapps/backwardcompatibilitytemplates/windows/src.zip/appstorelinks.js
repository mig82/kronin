//Type your code here
function openAppstoreApp() {
    var platname = (kony.os.deviceInfo().name).toLowerCase();
    //alert("platname:::"+platname);
    if (platname === "iphone") {
        kony.application.openURL("https://itunes.apple.com/us/app/kony-visualizer/id714162620");
    } else if (platname === "ipad") {
        kony.application.openURL("https://itunes.apple.com/in/app/kony-visualizer-tablet/id762649898");
    } else if (platname === "android") {
        kony.application.openURL("market://details?id=com.kony.FunctionPreviewApp");
    } else if (platname === "androidtab") {
        kony.application.openURL("market://details?id=com.kony.FunctionPreviewAppTab");
    } else if (/windows/.test(platname)) {
        kony.application.openURL("https://www.microsoft.com/en-US/store/apps/Kony-Visualizer/9NBLGGGZPGMZ");
    }
}