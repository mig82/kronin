//actions.js file 
function AS_Button_89c472a99faf4dd68b7e9448d9126155(eventobject) {
    return openAppstoreApp.call(this);
}