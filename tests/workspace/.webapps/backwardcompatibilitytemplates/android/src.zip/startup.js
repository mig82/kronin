//startup.js 
var appConfig = {
    appId: "Project073bcc1587",
    appName: "Templates",
    appVersion: "1.0.0",
    serverIp: "",
    serverPort: "",
    secureServerPort: "",
    isMFApp: false,
    eventTypes: [],
    url: null,
    secureurl: null
};
sessionID = "";

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        marginsIncludedInWidgetContainerWeight: true,
        APILevel: 7100
    })
};

function appInit(params) {
    skinsInit();
    frm1Globals();
    setAppBehaviors();
    if (typeof startBackgroundWorker != "undefined") {
        startBackgroundWorker();
    }
};

function postAppInitCallBack() {
    apppostappinitFuncPreview();
};

function themeCallBack() {
    callAppMenu();
    initializeGlobalVariables();
    kony.application.setApplicationInitializationEvents({
        init: appInit,
        postappinit: postAppInitCallBack,
        showstartupform: function() {
            frm1.show();
        }
    });
};

function onSuccess(oldlocalname, newlocalename, info) {
    kony.i18n.setCurrentLocaleAsync("en_US", loadResources, loadResources, null);
};

function onFailure(errorcode, errormsg, info) {
    loadResources();
};

function loadResources() {
    globalhttpheaders = {};
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
};
kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
//This is the entry point for the application.When Locale comes,Local API call will be the entry point.
kony.i18n.setDefaultLocaleAsync("en_US", onSuccess, onFailure, null);