function addWidgetsfrm1() {
    frm1.setDefaultUnit(kony.flex.DP);
    var Label0c2361ef48af244 = new kony.ui.Label({
        "height": "80%",
        "id": "Label0c2361ef48af244",
        "isVisible": true,
        "left": "5%",
        "right": "5%",
        "skin": "CopyslLabel0989a0f7588cf4e",
        "text": "  Please update the app from App Store to be compatible with this Visualizer version",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "90%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Button0223b673392994a = new kony.ui.Button({
        "centerX": "50%",
        "focusSkin": "slButtonGlossRed",
        "height": "60dp",
        "id": "Button0223b673392994a",
        "isVisible": true,
        "left": "13.95%",
        "onClick": AS_Button_89c472a99faf4dd68b7e9448d9126155,
        "skin": "CopyslButtonGlossBlue06aad5f7c814249",
        "text": "UPDATE",
        "top": "53.51%",
        "width": "271dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frm1.add(Label0c2361ef48af244, Button0223b673392994a);
};

function frm1Globals() {
    frm1 = new kony.ui.Form2({
        "addWidgets": addWidgetsfrm1,
        "enabledForIdleTimeout": false,
        "id": "frm1",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0261fa7a07be645"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
    frm1.info = {
        "kuid": "0773d7648a6542e09ffd3a8a5646dea4"
    };
};