
/**
 * Reads an annotation from DS.
 * @param {Object} params
 * @param {Object} params.proj_guid (Project unique ID)
 * @param {Object} params.annotation_id (Form ID _ Widget ID)
 * @param {Object} params.channel (channel)
 */

var __getDSObjIdForAnnotation__ = function(params) {
    return params.proj_guid + '_annotations_' + params.channel;
}


/**
 * Reads an annotation from DS.
 * @param {Object} params
 * @param {Object} params.proj_guid (Project unique ID)
 * @param {Object} params.annotation_id (Form ID _ Widget ID)
 * @param {Object} params.channel (channel)
 */

var __readAnnotationFromDataStore__ = function(params) {
    var dsObjID = __getDSObjIdForAnnotation__(params);

    if (kony.store.getItem(dsObjID) && Object.keys(kony.store.getItem(dsObjID)).length > 0) {
        var annotationsMap = kony.store.getItem(dsObjID);
            if (annotationsMap[params.annotation_id]) {
                return annotationsMap[params.annotation_id];
            }
    }
    return null;
}


/**
 * Writes an annotation to DS.
 * @param {Object} params
 * @param {Object} params.proj_guid (Project unique ID)
 * @param {Object} params.annotation_id (Form ID _ Widget ID)
 * @param {Object} params.channel (channel)
 * @param {Object} annotation (annotation)
 */

var __writeAnnotationToDataStore__ = function(params, annotation) {
    var dsObjID = __getDSObjIdForAnnotation__(params);
    
    if (kony.store.getItem(dsObjID) && Object.keys(kony.store.getItem(dsObjID)).length > 0) {
        var annotationsMap = kony.store.getItem(dsObjID);
        if(annotation != null)
            annotationsMap[params.annotation_id] = annotation;
        
        kony.store.setItem(dsObjID,annotationsMap);
    } else {
        var annotationsMap = {};
        if(annotation != null)
            annotationsMap[params.annotation_id] = annotation;
        kony.store.setItem(dsObjID,annotationsMap);
    }
}

/**
 * Adds or appends new comments for a widget.
 * @param {Object} params
 * @param {Object} params.proj_guid (Project unique ID)
 * @param {Object} params.annotation_id (Form ID _ Widget ID)
 * @param {Object} params.channel (channel)
 */


var __addOrAppendAnnotationTODS__ = function(params, newannotation, callback) {
    var annotationParam = newannotation;
    var kvsession = kony.ds.read("kvsession")[0];
    var userDetails = kvsession['userDetails'];
    var annotation_id = params.annotation_id;
    annotationParam.widgetId = annotation_id;
    annotationParam.formId = annotation_id;

    function appendToListAndSave(currentAnnotations) {
        var newAnnotation = annotationsUtil.createComment(annotationParam, userDetails);
        var commentId = newAnnotation.commentId;
        if(!currentAnnotations['comments'][annotationParam.widgetId]) {
            currentAnnotations['comments'][annotationParam.widgetId] = {};
        }
        currentAnnotations['comments'][annotationParam.widgetId][commentId] = newAnnotation;
        __writeAnnotationToDataStore__(params, currentAnnotations);
       // kony.print("Current Annotation" + JSON.stringify(currentAnnotations));
        return currentAnnotations;
    }
    try {
        var data = null;
        if (__readAnnotationFromDataStore__(params) !== null) {
            var annotation = __readAnnotationFromDataStore__(params);
            annotationParam.channel = params.channel;
            data = appendToListAndSave(annotation);
        } else {
            annotationParam.channel = params.channel;
            data = appendToListAndSave({
                widgetId: annotation_id,
                active: 1,
                comments: {}
            });
        }
        callback({
            "status": 400,
            "error": null,
            "data": data
        });
    } catch (e) {
        callback({
            "status": 200,
            "err": e,
            "data": null
        });
    }
};

/**
 * deletes a comment for a widget.
 * @param {Object} params
 * @param {Object} params.proj_guid (Project unique ID)
 * @param {Object} params.annotation_id (Form ID _ Widget ID)
 * @param {Object} params.channel (channel)
 * @param {Object} comment (Comment)
 */


var __deleteCommentFROMDS__ = function(params, comment, callback) {
    comment.active = 0;
    __updateCommentTODS__(params, comment, callback);
};


/**
 * updates an existing comment for a widget.
 * @param {Object} params
 * @param {Object} params.proj_guid (Project unique ID)
 * @param {Object} params.annotation_id (Form ID _ Widget ID)
 * @param {Object} params.channel (channel)
 * @param {Object} params.annotation (annotation)
 */

var __updateCommentTODS__ = function(params, comment, callback) {
    var kvsession = kony.ds.read("kvsession")[0];
    var userDetails = kvsession['userDetails'];
    try {
        if (__readAnnotationFromDataStore__(params) !== null) {
            var annotation = __readAnnotationFromDataStore__(params);
            annotation = annotationsUtil.updateComment(comment, userDetails, annotation);
            __writeAnnotationToDataStore__(params, annotation);
            callback({
                "status": 400,
                "error": null,
                "data": annotation
            });
        }
    } catch (e) {
        callback({
            "status": 200,
            "err": e,
            "data": null
        });
    }
};


/**
 * returns the whole annotation and returns the object for a widget
 * @param {Object} params
 * @param {Object} params.proj_guid (Project unique ID)
 * @param {Object} params.annotation_id (Form ID _ Widget ID)
 * @param {Object} params.channel (channel)
 */

var __openAnnotation__ = function(params, callback) {
    if (__readAnnotationFromDataStore__(params) !== null) {
        var annotation = __readAnnotationFromDataStore__(params);
        callback({
            "status": 400,
            "data": annotation
        });
    } else {
        callback({
            "status": 200,
            "data": null
        });
    }
};


var fpas = {
    addOrAppendAnnotationTODS : __addOrAppendAnnotationTODS__,
    updateCommentTODS : __updateCommentTODS__,
    deleteCommentFROMDS : __deleteCommentFROMDS__,
    openAnnotation : __openAnnotation__,
    readAnnotationFromDataStore : __readAnnotationFromDataStore__,
    writeAnnotationToDataStore : __writeAnnotationToDataStore__
};