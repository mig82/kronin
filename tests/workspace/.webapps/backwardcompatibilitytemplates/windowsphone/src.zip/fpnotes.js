var iterationStartTime;

// Saving platform name as 2 cases of platform specific changes are made -
// 1. invokeServiceAsync2 is used for windows 8 phone and tablet
// 2. httpResponse key is returned as part of resulttable return. This is case sensitive in windows 8 phone and tablet
var platformName = (kony.os.deviceInfo().name).toLowerCase();
var isWindows = false;

if ( platformName == 'windows' || platformName == 'windowsphone' ) {
	isWindows = true;
}

var __getAuthHeader__ = function (method, url) {

	var koauth = new KOAuth(null,
			null,
			notesDBURLs.consumerKey,
			notesDBURLs.consumerSecret,
			KOAuth._constants.VERSION_1_0,
			"",
			KOAuth._constants.SIGNATURE_SHA1);

	var accToken = kony.ds.read("acc_token");
	var oauth_token = null;
	var oauth_secret = null;
	if (accToken != null && accToken != undefined) {
		oauth_token = accToken[0]["oauth_access_token"];
		oauth_secret = accToken[0]["oauth_access_token_secret"]
	} else return;

	var headers = {};
	var orderedParameters = koauth._prepareParameters(oauth_token, oauth_secret, method, url, null);
	var authorization = koauth._buildAuthorizationHeaders(orderedParameters);
	headers[KOAuth._constants.HTTP_AUTHORIZATION_HEADER] = authorization;
	for (var keys in koauth._headers) {
		if (koauth._headers.hasOwnProperty(keys))
			headers[keys] = koauth._headers[keys];
	}
	kony.print("@@@@@@HEADER PARAMS: " + JSON.stringify(headers));
	return headers;
}

/**
 * updates the annotations for a widget into the DB.
 * @param {Object} params
 * @param {Object} params.proj_guid (Project unique ID)
 * @param {Object} params.annotation_id (Form ID _ Widget ID)
 * @param {Object} params.channel (channel)
 */

var __updateNotesToRemoteDB__ = function (params, callbackFP) {
	var dsObjID = __getDSObjIdForAnnotation__(params);
	var annotationsMap = {};
	if (kony.store.getItem(dsObjID))
		annotationsMap = kony.store.getItem(dsObjID);
	var i;
	var count = 0;
    var annProcessed = 0;
	params.callbackFP = callbackFP;
	params.annotationMapSize = Object.keys(annotationsMap).length;
	for (i in annotationsMap) { (function (annotation) {
			iterationStartTime = new Date();
			count++;
			annProcessed = count;
			processAnnotation(annotation, params, annProcessed);
		})(annotationsMap[i]);}
	//always sends status 200 to notify whether sync has been completed with remote or not.
	if (Object.keys(annotationsMap).length == 0) {
		//kony.print("DONE UPDATING COMMENTS TO DB");
		callbackFP({
			"status" : 200
		});
	}
};

var __cloneObject__ = function (obj) {
	if (null == obj || "object" != typeof obj) return obj;
	var copy = obj.constructor();
	for (var attr in obj) {
		if (obj.hasOwnProperty(attr)) copy[attr] = obj[attr];
	}
	return copy;
}

/**
 * Processes an annotation. At first reads and parses local file. Then checks whether it is a new annotation or not.
 * Depanded on that create a new annotation (sends a request to Shared Service to create a new note; stores returned note_guid.
 * Then updates all comments of the annotation.
 * @param {String} projectName
 * @private
 */
var processAnnotation = function (annotation, params, annProcessed) {
	try {

		params.dsObjID = __getDSObjIdForAnnotation__(params);

		function onCompleteAnnotationSync(is_synced) {
			kony.print(annotation.widgetId + " : Syncing annotation was completed!");

			var dsObjID = params.dsObjID;
			kony.print("SYNCED OR NOT FLAG IS : " + is_synced);
			if (is_synced) {
				annotation.synced_on = iterationStartTime.getTime();
			}

			if (kony.store.getItem(dsObjID) && Object.keys(kony.store.getItem(dsObjID)).length > 0) {
				var annotationsMap = kony.store.getItem(dsObjID);
				if (annotation != null)
					annotationsMap[annotation.widgetId] = annotation;
			}
			kony.store.setItem(dsObjID, annotationsMap);

			if (annProcessed == params.annotationMapSize || params.annotationMapSize == 0) {
				kony.print("DONE UPDATING COMMENTS TO DB");
				params.callbackFP({
					"status" : 200
				});
			}
		};

		annotation.id = annotation.widgetId;
		annotation.channel = params.channel;

		processNote(annotation, params, function (err, noteGuid) {
			kony.print("In callback for notes1");
			if (noteGuid) {
				kony.print("In callback for notes2");
				annotation.noteGuid = noteGuid;
				processComments(annotation, params, onCompleteAnnotationSync);
			} else {
				onCompleteAnnotationSync(false);
			}
		});
	} catch (ex) {
		kony.print('Error occurred during syncing annotation. Error: ' + ex + '!');
	}
};

/**
 * Sends a request to Shared service via visualizer service to create/update note.
 * @param {Object} param
 * @param {Object} comment
 * @param {Function} callback
 * @private
 */
var processNote = function (annotation, params, callback) {

	if (annotation.noteGuid) {
		delete annotation.noteGuid;
	}

	var noteParam = __cloneObject__(annotation);

	noteParam.formId = noteParam.widgetId = noteParam.id,
	noteParam.createdOn = new Date().getTime();
	noteParam.modifiedOn = noteParam.createdOn;

	var note = getNoteParam(noteParam);
	kony.print("NOTE PARAM BEING SENT" + JSON.stringify(note));
	var serviceURL = notesDBURLs.prototypeBase + notesDBURLs.prototypeApi + '/accounts/' + params.acc_guid + '/project/' + params.proj_guid + '/notes';

	function callbackForSaveNoteService(status, resulttable) {
		if (status == 400) {
			if (resulttable == null || resulttable == undefined) {
				return;
			}

			kony.print("MetaInfo resulttable FOR NOTES " + JSON.stringify(resulttable));

			if ('errmsg' in resulttable) {
				kony.print("Unable to reach host.");
				callback(resulttable.errmsg, null);
			} else if ('status' in resulttable) {
				kony.print("status : " + JSON.stringify(status));
				if (resulttable["status"]["code"] == 200) {
					if ('result' in resulttable) {
						var noteUrl = {};
						if (isWindows) {
							noteUrl = resulttable.httpResponse.headers['Location'];
						} else {
							noteUrl = resulttable.httpresponse.headers['Location'];
						}
						var parts = noteUrl.split('/');
						var noteId = parts[parts.length - 1];
						callback(null, noteId);
					}
				}
			}
		}
	};

	var headers = __getAuthHeader__('POST', serviceURL);

	checkPlatformsForInvokeService(serviceURL, {
		method : "post",
		timeout : 100
	},
		headers,
		JSON.stringify(note),
		callbackForSaveNoteService,
		null);


	};

	/**
	 * filters comments based on lastModifiedTime and annotation synced_on time. Returns the new comments.
	 * @param {Object} commentsObj
	 */

	var findNewOrUpdatedComments = function (commentsObj, annotation) {
		var updates = {};
		var widgetId;
		for (widgetId in commentsObj) {
			var widgetComments = commentsObj[widgetId];
			var commentId;
			for (commentId in widgetComments) {
				var commentObj = widgetComments[commentId];
				kony.print("validateComment(commentObj) : " + validateComment(commentObj));
				kony.print("annotation.synced_on" + annotation.synced_on);
				kony.print("new Date(commentObj.lastModifiedTime) :" + new Date(commentObj.lastModifiedTime));
				kony.print("new Date(annotation.synced_on) :" + new Date(annotation.synced_on));
				if (validateComment(commentObj) && (!annotation.synced_on || new Date(commentObj.lastModifiedTime) > new Date(annotation.synced_on))) {
						updates[commentId] = commentObj;
					}
			}
		}
		kony.print("updates: " + JSON.stringify(updates));
		return updates;
	}

	/**
	 * Processes annotation's comments. If annotation wasn't synced (annotation.synced_on property is not set),
	 * else takes only those comments which lastModifiedTime is later than annotation.synced_on date.
	 * Sends a request to create/update each new comment.
	 * @param {Object} annotation
	 * @param {Function} completeHandler
	 * @private
	 */
	var processComments = function (annotation, params, completeHandler) {
		kony.print(params.dsObjID + ">>" + annotation.widgetId, "Processing comments");

		var commentsObj = annotation.comments; // all the comments for all the widgets.

		//iterate over all the comments for all widgets and put new comments in new comments object.
		var newOrUpdatedComments = findNewOrUpdatedComments(commentsObj, annotation);
		var commentsIds = Object.keys(newOrUpdatedComments);

		if (commentsIds.length == 0) {
			kony.print(params.dsObjID + ">>" + annotation.widgetId, "No new comments found.");
			completeHandler(true);
		} else {
			// kony.print("Comment updates "+ JSON.stringify(newOrUpdatedComments));
			var counter = commentsIds.length;
			var failedComments = [];
			function commentProccessHandler(failedCommentId, callback) {
				counter--;
				if (failedCommentId) {
					kony.print("PUSHING FAILED COMMENT" + failedCommentId);
					failedComments.push(failedCommentId);
				}
				if (counter == 0) {
					var is_synced;
					if (failedComments.length > 0) {
						is_synced = false;
					} else {
						is_synced = true;
					}
					completeHandler(is_synced);
				}
			};

			commentsIds.forEach(function (commentId) {
				var commentObj = newOrUpdatedComments[commentId];
				saveNewComment(annotation, params, commentObj, commentProccessHandler);
			});
		}
	};

	/**
	 * Sends a request to Shared service via visualizer service to create/update comment.
	 * @param {Object} annotation
	 * @param {Object} comment
	 * @param {Function} callback
	 * @private
	 */
	var saveNewComment = function (annotation, params, comment, callback) {
		try {
			kony.print(params.dsObjID + ">>" + annotation.widgetId, "Saving new comment.");
			var comment = getCommentParam(comment);

			kony.print("NOTE GUID FOR COMMENT" + annotation.noteGuid);
			var serviceURL = notesDBURLs.prototypeBase + notesDBURLs.prototypeApi + '/accounts/' + params.acc_guid + '/project/' + params.proj_guid + '/notes/' + annotation.noteGuid + '/comment';
			function callbackForSaveCommentService(status, resulttable) {
				if (status == 400) {
					if (resulttable == null || resulttable == undefined) {
						return;
					}

					kony.print("MetaInfo resulttable FOR COMMENTS " + JSON.stringify(resulttable));

					if ('errmsg' in resulttable) {
						kony.print("Unable to reach host.");
						kony.print("FAILED TO PUSH THE COMMENT : " + comment.comment);
						callback(comment.guid);
					} else if ('status' in resulttable) {
						if (resulttable["status"]["code"] == 200) {
							if ('result' in resulttable) {
								kony.print("PUSHED THE COMMENT SUCCESSFULLY : " + comment.comment);
								callback(null);
							}
						}
					}
				}
			};

			var headers = __getAuthHeader__('POST', serviceURL);

			checkPlatformsForInvokeService(serviceURL, {
				method : "post",
				timeout : 100
			},
				headers,
				JSON.stringify(comment),
				callbackForSaveCommentService,
				null);


		} catch (ex) {
			callback(comment.guid);
		}
	};

	/**
	 * Checks required properties of comment object for validation before sending to Shared Service
	 * @param {Object} comment
	 * @private
	 * @returns {Boolean}
	 */
	var validateComment = function (comment) {
		return comment.commentId && comment.createdOn && comment.createdById && comment.createdBy &&
		comment.createdByEmail && comment.lastModifiedTime && comment.comment && comment.createdBy != 'Anonymous';
	};

	/**
	 * fetches the annotations for a widget from the DB and saves it to local datastore.
	 * @param {Object} params
	 * @param {Object} params.proj_guid (Project unique ID)
	 * @param {Object} params.annotation_id (Form ID _ Widget ID)
	 * @param {Object} params.channel (channel)
	 */

	var __fetchNotesFromRemoteDB__ = function (params, callback) {
		var current_ann_id = params.annotation_id;
		var updated_since;
		var db_sync_time_array = [];
		var lastPullTime = params.proj_guid + "_lastPullTime";
		if (kony.store.getItem(lastPullTime) && kony.store.getItem(lastPullTime).length > 0) {
			updated_since = kony.store.getItem(lastPullTime)[0].updated_since || 1;
		}

		function updateAnnotation(annotation, newComment) {
			newComment = formatComment(newComment);
			var widgetId = newComment.widgetId;
			if (!annotation['comments'][widgetId]) {
				annotation['comments'][widgetId] = {};
			}
			var comments = annotation['comments'][widgetId];
			var commentId = newComment['commentId'];
			comments[commentId] = newComment;
			annotation.synced_on = new Date().getTime();
			annotation['comments'][widgetId] = comments;
			return annotation;
		}

		kony.print("FETCHING PROJECT PARAMS" + JSON.stringify(params));
		var retrieveURL;
		if (updated_since) {
			retrieveURL = notesDBURLs.prototypeBase + notesDBURLs.prototypeApi + '/accounts/' + params.acc_guid + '/project/' + params.proj_guid + '/channel/' + params.channel + '/comments/' + updated_since;
		} else {
			retrieveURL = notesDBURLs.prototypeBase + notesDBURLs.prototypeApi + '/accounts/' + params.acc_guid + '/project/' + params.proj_guid + '/channel/' + params.channel + '/comments/';
		}

		function callbackForFetchNotesService(status, resulttable) {
			var fetchparams = __cloneObject__(params);
			var dsObjID = __getDSObjIdForAnnotation__(fetchparams);
			// kony.print("@@@@@@@@@@@@@@@@@@@@@Annotations Map : " + JSON.stringify(kony.store.getItem(dsObjID)));
			var annotationsMap = {};
			if (kony.store.getItem(dsObjID))
				annotationsMap = kony.store.getItem(dsObjID);

			//kony.print("status: " + status);
			//kony.print("result: " + JSON.stringify(resulttable));
			if (status == 400) {
				if (resulttable == null || resulttable == undefined) {
					return;
				}

				kony.print("MetaInfo resulttable " + JSON.stringify(resulttable));

				if ('errmsg' in resulttable) {
					kony.print("Unable to reach host.");
					callback({
						"status" : 500,
						"error" : "Could not reach the host"
					});
				} else if ('status' in resulttable) {
					if (resulttable["status"]["code"] == 200) {
						if ('result' in resulttable) {
							var newComments = resulttable["result"];
							var i;
							for (i in newComments) {
								var commentObj = newComments[i];
								kony.print('New COMMENT ' + JSON.stringify(commentObj));
								fetchparams.annotation_id = commentObj.widget_id;
								fetchparams.channel = commentObj.channel;
								db_sync_time_array.push(new Date(commentObj.db_sync_time).getTime()); //sync modified time stamp

								if (annotationsMap[fetchparams.annotation_id] != null && annotationsMap[fetchparams.annotation_id] != undefined) {
									var annotation = annotationsMap[fetchparams.annotation_id];
									annotation = updateAnnotation(annotation, commentObj);
									if (annotation != null)
										annotationsMap[fetchparams.annotation_id] = annotation;
								} else {
									var annotation = updateAnnotation({
											widgetId : fetchparams.annotation_id,
											active : 1,
											comments : {}
										}, commentObj);
									if (annotation != null)
										annotationsMap[fetchparams.annotation_id] = annotation;
								}
							}
						}
					}
				}
			}

			kony.store.setItem(dsObjID, annotationsMap);

			if (db_sync_time_array.length > 0) {
				updated_since = Math.max.apply(Math, db_sync_time_array);
				kony.print("updated_since TIME STAMP" + updated_since);
			}
			kony.store.setItem(lastPullTime, [{
						"updated_since" : updated_since
					}
				]);

			params.annotation_id = current_ann_id;
			if (fpas.readAnnotationFromDataStore(params) !== null) {
				var annotation = fpas.readAnnotationFromDataStore(params);
				//kony.print("CURRENT ANNOTATION " +  JSON.stringify(annotation));
				callback({
					"status" : 200,
					"data" : annotation
				});
			} else {
				callback({
					"status" : 500,
					"error" : "Could not read annotation from Data store"
				});
			}
		}

		kony.print("FETCHING COMMENTS");
		var headers = __getAuthHeader__('GET', retrieveURL);
        if(isWindows){
            var current = new Date(1970,01,01);
            headers["if-modified-since"] = current.toUTCString();
        }

		kony.net.invokeServiceAsync(retrieveURL, {
			httpconfig: {
			method: "get",
			timeout: 100
			},
			httpheaders: headers
			},
		callbackForFetchNotesService, null);
	};

	var fpnotes = {
		updateNotesToRemoteDB : __updateNotesToRemoteDB__,
		fetchNotesFromRemoteDB : __fetchNotesFromRemoteDB__
	};

	// Check to verify platform on FP app
	// if Windows phone 8 or tablet is found, use invokeServiceAsync2 API call. Otherwise use invokeServiceAsync
	var checkPlatformsForInvokeService = function (serviceURL, httpObject, headers, body, callback, additionalParameter) {
		if (isWindows) {
			kony.print("Calling Windows network service");
			kony.print("body : " + JSON.stringify(body));
			kony.print("headers : " + JSON.stringify(headers));
			kony.net.invokeServiceAsync2(serviceURL, {
				httpconfig : httpObject,
				httpheaders : headers,
				json : body
			},
				callback, additionalParameter);
		} else {
			kony.print("Calling Non-windows network service");
			kony.net.invokeServiceAsync(serviceURL, {
				httpconfig : httpObject,
				httpheaders : headers,
				json : body
			},
				callback, additionalParameter);
		}
	}
	