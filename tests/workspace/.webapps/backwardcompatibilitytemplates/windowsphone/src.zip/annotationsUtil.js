/**
 * create structured comment with time stamps and user details
 * @param {Object} commentParam (new comment param)
 * @param {Object} userDetails (user details)
 */

var createComment = function(commentParam, userDetails) {
    var newComment = {};
    if (userDetails) {
        newComment.createdById = userDetails['user_guid'];
        newComment.createdBy = userDetails['first_name'] + ' ' + userDetails['last_name'];
        newComment.createdByEmail = userDetails['primary_email'];
    } else {
        newComment.createdById = null;
        newComment.createdBy = 'Anonymous';
        newComment.createdByEmail = null;
    }

    var commentId = generateCommentId();
    newComment["commentId"] = commentId;
    newComment["label"] = commentParam.label || '';
    newComment["createdOn"] = new Date().getTime();
    newComment["lastModifiedTime"] = newComment["createdOn"];
    newComment["active"] = 1;
    newComment["widgetId"] = commentParam.widgetId;
    newComment["formId"] = commentParam.formId;
    newComment["channel"] = commentParam.channel;
    newComment["comment"] = commentParam.comment;

    return newComment;
};

var createRequirement = function(reqParam, userDetails) {
    var req = createComment(reqParam, userDetails);
    req.requirementId = req.commentId;
    req.body = reqParam.body;
    delete req.commentId;
    return req;
};

/**
 * update a comment in the comments map.
 * @param {Object} comment (new comment)
 * @param {Object} userDetails (user details)
 * @param {Object} annotation (current annotations object)
 */

var updateComment = function(comment, userDetails, annotation) {

    var commentId = comment['commentId'];
    var widgetId = comment['widgetId'];
    var comments = annotation.comments[widgetId];
    if (typeof comments[commentId] !== 'undefined') {
        var currentUid = userDetails ? userDetails['user_guid'] : null;

        // access control
        if (!comments[commentId].createdById && currentUid) {
            // take ownership on anonymous comments
            comment["createdById"] = currentUid;
            comment["createdBy"] = userDetails['first_name'] + ' ' + userDetails['last_name'];
            comment["createdByEmail"] = userDetails['primary_email'];
            comment["createdOn"] = new Date().getTime();
        } else if (currentUid && currentUid != comments[commentId].createdById) {
            // user mismatch
            //kony.print('Could not update comment: user mismatch.');
            return annotation;
        }
        comment["active"] = Number(comment["active"]);
        comment["lastModifiedTime"] = new Date().getTime();
        comments[commentId] = comment;
        annotation.comments[widgetId] = comments;
    }
    return annotation;
};

/**
 * Update given requirement in annotation.
 */
var updateRequirement = function(requirement, userDetails, annotation) {
    var wgtId = requirement.widgetId,
        id = requirement.requirementId;
    //No access control for now.
    requirement.active = Number(requirement.active);
    //latModifiedTime has to be updated by client
    //requirement.lastModifiedTime = new Date().getTime();
    requirement.lastModifiedTime = Number(requirement.lastModifiedTime);
    annotation.requirements[wgtId][id] = requirement;
    return annotation;
};

/**
 * Generated unique Id for a comment.
 *
 */

var generateCommentId = function() {
    return 'xxxx-xxxx-xxxx-xxxx-xxxx-xxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0,
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
};

/**
 * Transforms local comment object to Shared Service param - comment
 * @param {Object} comment
 * @returns {Object}
 */
var getCommentParam = function(comment) {
    return {
        guid: comment.commentId,
        created_on: Number(comment.createdOn),
        created_by_guid: comment.createdById,
        created_by: comment.createdBy,
        created_by_email: comment.createdByEmail,
        modified_on: Number(comment.lastModifiedTime),
        comment: comment.comment,
        comment_src: (typeof(module) !== 'undefined' && module.exports) ?
            COMMENT_SRC_APP.VIZ : COMMENT_SRC_APP.FP,
        active: comment.active,
    }
};

/**
 * Transform local note object to Shared Service param - note
 * @param {Object} note
 * @return {Object}
 */
var getNoteParam = function(note) {
    return {
        guid: note.noteGuid,
        widget_id: note.widgetId,
        form_id: note.formId,
        form_channel: note.channel,
        created_on: Number(note.createdOn),
        modified_on: Number(note.modifiedOn),
        active: note.active
    };
};

/**
 * Format comment params as a comment object to be stored in
 * annotations file
 */
var formatComment = function(params) {
    return {
        commentId: params.guid,
        widgetId: params.widget_id,
        formId: params.form_id,
        createdOn: new Date(params.created_on).getTime(),
        createdById: params.created_by_guid,
        createdBy: params.created_by,
        createdByEmail: params.created_by_email,
        lastModifiedTime: new Date(params.modified_on).getTime(),
        comment: params.comment,
        commentSrc: params.comment_src,
        active: params.active,
        channel: params.form_channel
    };
};

/**
 * Filter requirements from all comments
 */
var filterRequirements = function(arr) {
    return arr.filter(function(req) {
        return req.type === 2;
    });
};

var annotationsUtil = {
        'createComment' : createComment,
        'updateComment': updateComment,
        'generateCommentId' : generateCommentId,
        'getCommentParam' : getCommentParam,
        'getNoteParam': getNoteParam,
        'formatComment' : formatComment,
        'createRequirement': createRequirement,
        'updateRequirement': updateRequirement,
        'filterRequirements': filterRequirements
};

var COMMENT_SRC_APP = {
    FP: 'functional preview',
    VIZ: 'visualizer'
};

var COMMENT_TYPE = {
    COMMENT: 1,
    REQUIREMENT: 2
};

//export as node module when running in node
if(typeof(module) !== 'undefined' && module.exports) {
    module.exports = annotationsUtil;
}