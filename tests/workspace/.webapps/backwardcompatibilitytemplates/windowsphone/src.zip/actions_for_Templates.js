//actions.js file 
function AS_Button_19d1bd6bccc24624af016ae6c9651aea(eventobject) {
    return openAppstoreApp.call(this);
}