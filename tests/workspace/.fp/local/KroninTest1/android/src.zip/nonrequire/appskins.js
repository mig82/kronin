function skinsInit() {
    defBtnFocus = "defBtnFocus";
    defBtnNormal = "defBtnNormal";
    defLabel = "defLabel";
    sknLblDescription = "sknLblDescription";
    sknLblRowHeading = "sknLblRowHeading";
    sknLblStrip = "sknLblStrip";
    sknLblTimeStamp = "sknLblTimeStamp";
    sknSampleRowTemplate = "sknSampleRowTemplate";
    sknSampleSectionHeaderTemplate = "sknSampleSectionHeaderTemplate";
    sknSectionHeaderLabelSkin = "sknSectionHeaderLabelSkin";
    slDynamicNotificationForm = "slDynamicNotificationForm";
    slForm = "slForm";
    slPopup = "slPopup";
    slStaticNotificationForm = "slStaticNotificationForm";
    slTitleBar = "slTitleBar";
    slWatchForm = "slWatchForm";
};